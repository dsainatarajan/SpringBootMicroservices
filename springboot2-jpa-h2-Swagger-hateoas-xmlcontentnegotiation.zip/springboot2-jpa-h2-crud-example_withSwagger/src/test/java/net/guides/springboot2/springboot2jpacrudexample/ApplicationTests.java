package net.guides.springboot2.springboot2jpacrudexample;



import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@SpringBootTest
public class ApplicationTests {


	public void contextLoads() {
	}

}
